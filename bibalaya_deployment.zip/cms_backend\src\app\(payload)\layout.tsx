/* THIS FILE WAS GENERATED AUTOMATICALLY BY PAYLOAD. */
import config from '@/payload.config'
import '@payloadcms/next/css'
import { handleServerFunctions, RootLayout } from '@payloadcms/next/layouts'
import React from 'react'

import { importMap } from './admin/importMap'

type Args = {
    children: React.ReactNode
}

const serverFunction = async (args: {
    req: Request
    query: Record<string, unknown>
}) => {
    'use server'
    return handleServerFunctions({
        ...args,
        config,
        importMap,
    })
}

const Layout = ({ children }: Args) => (
    <RootLayout config={config} importMap={importMap} serverFunction={serverFunction}>
        {children}
    </RootLayout>
)

export default Layout
